package com.cg.springboot.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.springboot.entity.LoanApplication;

@Repository
public interface LoanRepo extends JpaRepository<LoanApplication, Long>  {
//muskannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
}
