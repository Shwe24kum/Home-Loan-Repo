package com.cg.springboot.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springboot.entity.LoanApplication;
import com.cg.springboot.repo.FinanceVerificationOfficerRepo;
import com.cg.springboot.repo.LoanRepo;

//muskannnnnnnnnnnnnnnnnn
@Service
public class LoanServiceImpl implements LoanService {
	
	@Autowired
	LoanRepo loanrepo;
	@Autowired
	FinanceVerificationOfficerRepo financeVerificatonOfficerRepo;

	@Override
	public void addLoanApplication(LoanApplication loanApplication) {
		
		loanrepo.save(loanApplication);
		
	}
	

}
