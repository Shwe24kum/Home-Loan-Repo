package com.cg.springboot.service;

import com.cg.springboot.entity.LoanApplication;

import ch.qos.logback.core.status.Status;


//MUSKANNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
public interface LoanService {
	
	void addLoanApplication(LoanApplication loanApplication);


	

//	static Status updateStatus(int loanAppId, Status status) {
//		// TODO Auto-generated method stub
//		return status;
//	}

	

//	void addLoan(String userId, LoanApplication loanApplication);

}
