package com.cg.springboot.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springboot.entity.Users;
import com.cg.springboot.repo.UserRepo;

@Service
public class UsersServiceImpl implements UsersService{
	
	@Autowired
	UserRepo userRepo;

	
	//add users validation
	@Override
	public void addUsers(Users users) {
//		
//		Optional<Users> user1 = userRepo.findById((int) users.getUserId());
//		
//		userRepo.save(user1);
		
		List<Users> user1 =userRepo.findAll();
		if(user1.isEmpty()) {
			userRepo.save(users);
			
		}
		else{for(Users u : user1) {
			if(u.getUserId().equals(users.getUserId())) {
				throw new RuntimeException("user id alredy exist");
			}
			else {
//				throw new RuntimeException("user id not present");
				userRepo.save(users);
			}
		}
		}
	}

}
