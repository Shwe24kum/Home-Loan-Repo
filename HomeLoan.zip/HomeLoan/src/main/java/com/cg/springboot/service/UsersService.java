package com.cg.springboot.service;

import org.springframework.stereotype.Service;

import com.cg.springboot.entity.Users;

@Service
public interface UsersService {

	void addUsers(Users users);

}
