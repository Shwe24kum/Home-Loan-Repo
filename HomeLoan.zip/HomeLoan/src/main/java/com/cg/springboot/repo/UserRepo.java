package com.cg.springboot.repo;

import java.util.Optional;

import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.springboot.entity.Users;



//muskann
@Repository
//@Primary
public interface UserRepo extends JpaRepository<Users, Integer>{
	
	Optional<Users> findByUserIdAndPassword(String userId, String password);
	@Query("from Users u where u.userId =?1")
	
	public Users getById(String users);

	
//public interface UserRepo extends JpaRepository<User, String>{

}
