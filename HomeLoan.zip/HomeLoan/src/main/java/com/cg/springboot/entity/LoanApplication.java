package com.cg.springboot.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="LoanApplication")
public class LoanApplication {
	//muskannnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long applicationId;

//	@JsonFormat(pattern="yyyy-mm-dd")
	private LocalDate applicationDate;
	private double loanAppliedAmount;
	private double loanApprovedAmount;
	private boolean landVerificationApproval;
	private boolean finananceVerificationApproval;
	private boolean adminApproval;
	private Status status;
	
	@OneToOne
	@JoinColumn(name="financeUser_Id")
	private FinanceVerificationOfficer financer;

	public LoanApplication() {
		super();
	}
	//yha ek extra hai...check once

	public LoanApplication(long applicationId, LocalDate applicationDate, double loanAppliedAmount,
			double loanApprovedAmount, boolean landVerificationApproval, boolean finananceVerificationApproval,
			boolean adminApproval, Status status, FinanceVerificationOfficer financer) {
		super();
		this.applicationId = applicationId;
		this.applicationDate = applicationDate;
		this.loanAppliedAmount = loanAppliedAmount;
		this.loanApprovedAmount = loanApprovedAmount;
		this.landVerificationApproval = landVerificationApproval;
		this.finananceVerificationApproval = finananceVerificationApproval;
		this.adminApproval = adminApproval;
		this.status = status;
		this.financer = financer;
	}

	public long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(long applicationId) {
		this.applicationId = applicationId;
	}

	public LocalDate getApplicationDate() {
		return applicationDate;
	}

	public void setApplicationDate(LocalDate applicationDate) {
		this.applicationDate = applicationDate;
	}

	public double getLoanAppliedAmount() {
		return loanAppliedAmount;
	}

	public void setLoanAppliedAmount(double loanAppliedAmount) {
		this.loanAppliedAmount = loanAppliedAmount;
	}

	public double getLoanApprovedAmount() {
		return loanApprovedAmount;
	}

	public void setLoanApprovedAmount(double loanApprovedAmount) {
		this.loanApprovedAmount = loanApprovedAmount;
	}

	public boolean isLandVerificationApproval() {
		return landVerificationApproval;
	}

	public void setLandVerificationApproval(boolean landVerificationApproval) {
		this.landVerificationApproval = landVerificationApproval;
	}

	public boolean isFinananceVerificationApproval() {
		return finananceVerificationApproval;
	}

	public void setFinananceVerificationApproval(boolean finananceVerificationApproval) {
		this.finananceVerificationApproval = finananceVerificationApproval;
	}

	public boolean isAdminApproval() {
		return adminApproval;
	}

	public void setAdminApproval(boolean adminApproval) {
		this.adminApproval = adminApproval;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public FinanceVerificationOfficer getFinancer() {
		return financer;
	}

	public void setFinancer(FinanceVerificationOfficer financer) {
		this.financer = financer;
	}

	
}



	
	
	

//package com.cg.springboot.entity;
//
//import java.time.LocalDate;
//
//import javax.persistence.CascadeType;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.JoinColumn;
//import javax.persistence.OneToOne;
//import javax.persistence.Table;
//
//import com.fasterxml.jackson.annotation.JsonFormat;

	
	



//	@Override
//	public String toString() {
//		return "LoanApplication [applicationId=" + applicationId + ", applicationDate=" + applicationDate
//				+ ", loanAppliedAmount=" + loanAppliedAmount + ", loanApprovedAmount=" + loanApprovedAmount
//				+ ", landVerificationApproval=" + landVerificationApproval + ", finananceVerificationApproval="
//				+ finananceVerificationApproval + ", adminApproval=" + adminApproval + ", status=" + status
//				+ ", customer=" + customer + "]";
//	}
//	
	
	
	


