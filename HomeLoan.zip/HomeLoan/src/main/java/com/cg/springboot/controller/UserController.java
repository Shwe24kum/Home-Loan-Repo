package com.cg.springboot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springboot.entity.Users;
import com.cg.springboot.service.FinanceOfficerService;
import com.cg.springboot.service.UsersService;

@RestController
//@RequestMapping("/signIn")
public class UserController {
	
	
	@Autowired
	FinanceOfficerService financeService;
	
	
	@Autowired
	UsersService usersService;
	
	
//	
	@PostMapping("/addUser")
	public Users addUsers(@RequestBody Users users)
	{
		System.out.println(users.getUserId());
		usersService.addUsers(users);
		return users;
	}
	
	
	@PostMapping("/signIn")
	public Users signIn(@RequestBody Users users) {
		financeService.signIn(users);
		return users;
	}

}
